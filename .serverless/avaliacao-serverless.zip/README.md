# Projeto Final - 43scj_serverless_shoppinglist

<p align="center">
<img src="img\macro_trabalho_final.png" alt="Desenho macro de solução para o Trabalho">
</p>

> O objetivo deste projeto é desenvolver uma Lambda na AWS (pode ser na linguagem de programação de preferência do grupo e com runtime suportado pela plataforma).

## Integrantes do Grupo

- CAIO DE ARAUJO MORAIS RM: 345756 ✔️
- EVANDRO BORZI MARQUES RM: 345434 ✔️
- GIOVANNI RIBEIRO BENDINELLI TREVISAN RM: 344444 ✔️
- KAIQUE JUVENCIO COSTA RM: 345375 ✔️
- VINICIUS LUCAS SILVESTRE RM: 344213 ✔️

## :white_check_mark: Objetivos, Regras e Requisitos

O projeto contem as seguintes regras de avaliação

- [x] Documentação do projeto em Markdown
- [ ] Implementar Persistência
- [ ] Implementar Observability

## ☕ Usando e testando o projeto
